﻿# Islah Nexus MVP Release Manifest

## Release

Package: islah_nexus_mvp_20260505_031405.zip
Path: C:\Users\theis\islah_nexus_v0\dist\islah_nexus_mvp_20260505_031405.zip
Size bytes: 33457
Created: 2026-05-04T19:14:06.6305892Z

## SHA-256

7CFC9AB88E3C24FB439888C0EA99FC398D906432044BAA06BF87E5052433EF81

## Confirmed state

- MVP package created.
- MVP runner passing.
- Constitutional audit returns HALT_CONSTITUTIONAL.
- Law II Truth Gap enforced.
- Law VII Walang Maiiwan enforced.
- HALT_CONSTITUTIONAL exits with code 1.
- Anna online.
- Governance spine visible.
- Notion bridge synced.
- Truth Gap preserved.
- Walang Maiiwan.

## Truthkind note

This manifest identifies the current packaged MVP artifact.
Do not claim a newer package is verified until its hash is generated and logged.
