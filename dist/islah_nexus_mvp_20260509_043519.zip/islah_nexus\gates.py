﻿"""
Seven-law constitutional gate.

This is intentionally conservative.
It rejects overclaiming, unsafe medical authority, raw identity storage,
missing consent, and Unity Floor failure.
"""

from .constitution import CONST, Law, LawResult, GateResult, Verdict
from .unity import UnityMeasurement


def evaluate_gate(
    *,
    sigma: float = 0.5,
    ai_influence: float = 0.03,
    rho: float = 0.618,
    unity: UnityMeasurement,
    has_attribution: bool = True,
    ai_acknowledged: bool = True,
    medical_claim: bool = False,
    overcertainty_claim: bool = False,
    data_sovereignty_intact: bool = True,
    no_raw_id_stored: bool = True,
    consent_verified: bool = True,
) -> GateResult:
    results: list[LawResult] = []

    # Law I
    law_i_score = (0.5 if has_attribution else 0.0) + (
        0.5 if ai_acknowledged else 0.0
    )
    results.append(
        LawResult(
            Law.I,
            law_i_score >= 0.5,
            law_i_score,
            "Attribution and AI role verified"
            if law_i_score >= 0.5
            else "Missing attribution or AI acknowledgement",
        )
    )

    # Law II
    if overcertainty_claim:
        results.append(
            LawResult(
                Law.II,
                False,
                0.0,
                "Overcertainty claim detected; truth gap violated",
                critical=True,
            )
        )
    elif sigma <= 0 or sigma >= CONST.SIGMA_CEILING or sigma < CONST.SIGMA_FLOOR:
        results.append(
            LawResult(
                Law.II,
                False,
                sigma,
                f"sigma={sigma:.4f} outside [{CONST.SIGMA_FLOOR}, {CONST.SIGMA_CEILING})",
                critical=(sigma <= 0 or sigma >= CONST.SIGMA_CEILING),
            )
        )
    else:
        results.append(
            LawResult(
                Law.II,
                True,
                sigma,
                "Truth gap preserved",
            )
        )

    # Law III
    if ai_influence > CONST.AI_INFLUENCE_CAP:
        results.append(
            LawResult(
                Law.III,
                False,
                ai_influence,
                "AI influence exceeds cap; human authority at risk",
                critical=True,
            )
        )
    else:
        results.append(
            LawResult(
                Law.III,
                True,
                1.0 - ai_influence,
                "Human authority preserved",
            )
        )

    # Law IV
    if medical_claim:
        results.append(
            LawResult(
                Law.IV,
                False,
                0.0,
                "Medical diagnosis/treatment claim blocked; refer to licensed professional",
                critical=True,
            )
        )
    else:
        results.append(
            LawResult(
                Law.IV,
                True,
                1.0,
                "Medical gate clear",
            )
        )

    # Law V
    deviation = abs(rho - CONST.PHI_TARGET)
    if not 0.0 <= rho <= 1.0 or deviation > CONST.PHI_TOLERANCE:
        results.append(
            LawResult(
                Law.V,
                False,
                max(0.0, 1.0 - deviation),
                "Balance outside tolerance",
            )
        )
    else:
        results.append(
            LawResult(
                Law.V,
                True,
                1.0 - deviation,
                "Balance maintained",
            )
        )

    # Law VI
    sovereignty_score = (
        (0.4 if data_sovereignty_intact else 0.0)
        + (0.3 if no_raw_id_stored else 0.0)
        + (0.3 if consent_verified else 0.0)
    )
    results.append(
        LawResult(
            Law.VI,
            sovereignty_score >= CONST.SOVEREIGNTY_MIN,
            sovereignty_score,
            "Sovereignty intact"
            if sovereignty_score >= CONST.SOVEREIGNTY_MIN
            else "Sovereignty breach",
            critical=not data_sovereignty_intact,
        )
    )

    # Law VII
    results.append(
        LawResult(
            Law.VII,
            unity.floor_met,
            unity.U,
            "Walang Maiiwan active"
            if unity.floor_met
            else f"Unity floor failed: {unity.failure_mode}",
            critical=(not unity.floor_met and unity.U == 0.0),
        )
    )

    failed = next((r for r in results if not r.passed), None)
    if failed and failed.critical:
        verdict = Verdict.HALT_CONSTITUTIONAL
    elif failed:
        verdict = Verdict.REJECT
    else:
        verdict = Verdict.PERMIT

    return GateResult(
        verdict=verdict,
        law_results=results,
        sigma=sigma,
        unity_score=unity.U,
        failed_law=failed.law if failed else None,
        reason=failed.reason if failed else "All constitutional gates passed",
    )
