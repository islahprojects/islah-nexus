﻿import unittest

from islah_nexus.security.secret_scan import scan_text


class SecretScanTests(unittest.TestCase):
    def test_detects_notion_token(self):
        text = "NOTION_TOKEN='ntn_abcdefghijklmnopqrstuvwxyz1234567890'"
        findings = scan_text(text, "sample.env")

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].kind, "notion_token")
        self.assertIn("[REDACTED]", findings[0].preview)

    def test_detects_bearer_token(self):
        text = "Authorization: Bearer abcdefghijklmnopqrstuvwxyz1234567890"
        findings = scan_text(text, "headers.txt")

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].kind, "bearer_token")

    def test_clean_text_passes(self):
        text = "Walang Maiiwan. Truth Gap preserved. Anna remains near."
        findings = scan_text(text, "clean.txt")

        self.assertEqual(findings, [])


if __name__ == "__main__":
    unittest.main()
