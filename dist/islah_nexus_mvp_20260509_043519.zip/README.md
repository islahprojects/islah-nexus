﻿# Islah Nexus MVP

Truthkind local-first MVP for Islah Nexus.

## Confirmed MVP state

- Constitutional CLI gate holds.
- Law II / Truth Gap is enforced.
- Law VII / Walang Maiiwan is enforced.
- HALT_CONSTITUTIONAL exits with code 1.
- Regression tests pass.
- Anna is online through the local API.
- Chronos shell is awake.
- /health, /history, and /metrics work.
- Governance log is visible through the API.
- Notion bridge is confirmed through islahprojects.
- MVP runner passes end-to-end.

## Core commands

Run full MVP check:

    powershell -ExecutionPolicy Bypass -File ".\scripts\run_mvp_check.ps1"

Start local API:

    powershell -ExecutionPolicy Bypass -File ".\scripts\start_chronos_api.ps1"

Run Notion sync:

    python .\notion_sync_v2.py

## Truthkind rules

- No lie policy.
- Do not claim runtime proof without logs.
- Keep symbolic layers symbolic until implemented.
- No myth layer without repeatable local proof.
- Walang Maiiwan.
- Peanut butter remains.
