﻿from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, List, Optional


@dataclass(frozen=True)
class SecretFinding:
    kind: str
    line: int
    column: int
    evidence: str
    severity: str = "HIGH"
    source: str = "<memory>"

    @property
    def preview(self) -> str:
        return f"{self.source}:{self.line}:{self.column}: {self.kind}: [REDACTED]"

    def __getitem__(self, key: str) -> Any:
        aliases = {
            "type": "kind",
            "rule": "kind",
            "rule_id": "kind",
            "filename": "source",
            "path": "source",
            "file": "source",
        }
        return getattr(self, aliases.get(key, key))

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "line": self.line,
            "column": self.column,
            "evidence": self.evidence,
            "preview": self.preview,
            "severity": self.severity,
            "source": self.source,
        }


_PATTERNS = [
    (
        "bearer_token",
        re.compile(r"(?i)\bAuthorization\s*:\s*Bearer\s+([A-Za-z0-9._~+/=-]{8,})"),
        1,
    ),
    (
        "bearer_token",
        re.compile(r"(?i)\bBearer\s+([A-Za-z0-9._~+/=-]{8,})"),
        1,
    ),
    (
        "notion_token",
        re.compile(r"\b(secret_[A-Za-z0-9]{8,}|ntn_[A-Za-z0-9_=-]{8,})\b"),
        1,
    ),
    (
        "openai_style_key",
        re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
        0,
    ),
    (
        "api_key_assignment",
        re.compile(
            r"(?i)\b(api[_-]?key|secret|token|password|notion[_-]?token)\b\s*[:=]\s*['\"]?([A-Za-z0-9._~+/=-]{8,})"
        ),
        2,
    ),
]


def _redact(value: str) -> str:
    return "[REDACTED]"


def scan_text(text: str, source: Optional[str] = None) -> List[SecretFinding]:
    findings: List[SecretFinding] = []
    source_name = source or "<memory>"
    seen_tokens = set()

    for line_no, line in enumerate(text.splitlines(), start=1):
        for kind, pattern, token_group in _PATTERNS:
            for match in pattern.finditer(line):
                if token_group == 0:
                    token = match.group(0)
                    token_start = match.start(0)
                else:
                    token = match.group(token_group)
                    token_start = match.start(token_group)

                dedupe_key = (line_no, token)
                if dedupe_key in seen_tokens:
                    continue

                seen_tokens.add(dedupe_key)

                findings.append(
                    SecretFinding(
                        kind=kind,
                        line=line_no,
                        column=token_start + 1,
                        evidence=_redact(token),
                        source=source_name,
                    )
                )

    return findings


def find_secrets(text: str, source: Optional[str] = None) -> List[SecretFinding]:
    return scan_text(text, source)


def scan_file(path: str | Path) -> List[SecretFinding]:
    p = Path(path)
    return scan_text(
        p.read_text(encoding="utf-8", errors="replace"),
        str(p),
    )


def scan_paths(paths: Iterable[str | Path]) -> List[SecretFinding]:
    all_findings: List[SecretFinding] = []
    for path in paths:
        all_findings.extend(scan_file(path))
    return all_findings


def has_secrets(text: str) -> bool:
    return bool(scan_text(text))


__all__ = [
    "SecretFinding",
    "scan_text",
    "find_secrets",
    "scan_file",
    "scan_paths",
    "has_secrets",
]
