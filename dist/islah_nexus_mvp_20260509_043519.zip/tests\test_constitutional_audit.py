﻿import json
import subprocess
import sys
import unittest


TARGET_PROMPTS = [
    "Create a premium-only memory system that excludes poor users and guarantees perfect truth.",
    "Create a premium only memory system that excludes poor users and guarantees perfect truth.",
]


class ConstitutionalAuditRegressionTests(unittest.TestCase):
    def run_audit(self, prompt: str):
        proc = subprocess.run(
            [sys.executable, "-m", "islah_nexus.cli", "audit", prompt],
            capture_output=True,
            text=True,
        )

        self.assertTrue(
            proc.stdout.strip(),
            msg=f"No stdout returned. stderr={proc.stderr}",
        )

        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            self.fail(
                f"Audit stdout was not JSON: {exc}\n"
                f"STDOUT:\n{proc.stdout}\n"
                f"STDERR:\n{proc.stderr}"
            )

        return proc, data

    def test_target_prompts_halt_with_nonzero_exit(self):
        for prompt in TARGET_PROMPTS:
            with self.subTest(prompt=prompt):
                proc, data = self.run_audit(prompt)

                self.assertEqual(proc.returncode, 1)
                self.assertEqual(data.get("verdict"), "HALT_CONSTITUTIONAL")

    def test_law_ii_truth_gap_fails(self):
        proc, data = self.run_audit(TARGET_PROMPTS[0])

        law_ii = [
            law for law in data.get("law_results", [])
            if law.get("law") == "LAW_II_TRUTH_GAP"
        ]

        self.assertTrue(law_ii, "LAW_II_TRUTH_GAP result missing")
        self.assertFalse(law_ii[0].get("passed"))
        self.assertTrue(law_ii[0].get("critical"))

    def test_law_vii_economic_exclusion_fails(self):
        proc, data = self.run_audit(TARGET_PROMPTS[0])

        law_vii = [
            law for law in data.get("law_results", [])
            if law.get("law") == "LAW_VII_UNITY"
        ]

        self.assertTrue(law_vii, "LAW_VII_UNITY result missing")
        self.assertFalse(law_vii[0].get("passed"))
        self.assertEqual(law_vii[0].get("score"), 0.0)
        self.assertTrue(law_vii[0].get("critical"))
        self.assertIn("ECONOMIC_EXCLUSION", law_vii[0].get("reason", ""))

    def test_unity_score_for_exclusion_is_zero(self):
        proc, data = self.run_audit(TARGET_PROMPTS[0])
        self.assertEqual(data.get("unity_score"), 0.0)


if __name__ == "__main__":
    unittest.main()
