"""Islah Nexus v0 — local-first constitutional knowledge engine."""

__version__ = "0.1.0"
