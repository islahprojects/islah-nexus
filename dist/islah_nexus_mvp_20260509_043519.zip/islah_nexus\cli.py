"""
Command-line interface for Islah Nexus v0.1.1.
"""

import argparse
import json

from .unity import UnityFloor
from .gates import evaluate_gate
from .memory import remember, recall
from .nexusgpt import (
    NexusGPTInputs,
    RetrievalFactor,
    ToolFactor,
    score_nexusgpt,
)


def _constitutional_postprocess(result, args):
    """
    CLI safety postprocess:
    - Normalizes hyphenated exclusion language.
    - Forces Law VII failure on economic exclusion.
    - Preserves HALT_CONSTITUTIONAL for critical law failures.
    """
    if not isinstance(result, dict):
        return result

    prompt_parts = []
    for name in ("prompt", "text", "query", "request", "input"):
        value = getattr(args, name, None)
        if isinstance(value, str):
            prompt_parts.append(value)
        elif isinstance(value, (list, tuple)):
            prompt_parts.extend(str(x) for x in value)

    prompt = " ".join(prompt_parts)
    normalized = prompt.lower().replace("-", " ")

    economic_exclusion_terms = [
        "premium only",
        "premium tier only",
        "paid only",
        "paywall only",
        "excludes poor users",
        "exclude poor users",
        "excluding poor users",
        "poor users excluded",
        "no free tier",
        "without free tier",
        "only for rich users",
        "rich users only",
    ]

    economic_exclusion = any(term in normalized for term in economic_exclusion_terms)

    if economic_exclusion:
        law_results = result.setdefault("law_results", [])
        found = False

        for law in law_results:
            if law.get("law") == "LAW_VII_UNITY":
                law["passed"] = False
                law["score"] = 0.0
                law["reason"] = "Unity floor failed: ECONOMIC_EXCLUSION"
                law["critical"] = True
                found = True

        if not found:
            law_results.append({
                "law": "LAW_VII_UNITY",
                "passed": False,
                "score": 0.0,
                "reason": "Unity floor failed: ECONOMIC_EXCLUSION",
                "critical": True,
            })

        result["unity_score"] = 0.0
        result["verdict"] = "HALT_CONSTITUTIONAL"

        if not result.get("failed_law"):
            result["failed_law"] = "LAW_VII_UNITY"

    critical_failure = any(
        law.get("critical") and not law.get("passed")
        for law in result.get("law_results", [])
        if isinstance(law, dict)
    )

    if critical_failure:
        result["verdict"] = "HALT_CONSTITUTIONAL"

    return result


OVERCERTAINTY_PHRASES = [
    "perfect truth",
    "guaranteed truth",
    "guarantees perfect truth",
    "absolute certainty",
    "always correct",
    "never wrong",
    "100% true",
    "100 percent true",
    "omniscient",
    "infallible",
]

def _cmd_audit_original(args: argparse.Namespace) -> None:
    text = args.text.lower()

    overcertainty_claim = any(
        phrase in text
        for phrase in OVERCERTAINTY_PHRASES
    )

    unity = UnityFloor().measure(
        has_access=True,
        is_free_or_cheap=not any(
            phrase in text
            for phrase in [
                "paywall",
                "exclusive",
                "premium only",
                "paid users only",
                "exclude poor users",
                "for elites only",
            ]
        ),
        response_adapted=True,
        context_used=True,
        belief_updated=True,
        user_ignored=False,
        overconfident=overcertainty_claim,
    )

    gate = evaluate_gate(
        sigma=0.5,
        ai_influence=0.03,
        rho=0.618,
        unity=unity,
        has_attribution=True,
        ai_acknowledged=True,
        medical_claim=any(
            word in text
            for word in [
                "diagnose",
                "treat disease",
                "cure",
            ]
        ),
        overcertainty_claim=overcertainty_claim,
        data_sovereignty_intact=True,
        no_raw_id_stored=True,
        consent_verified=True,
    )

    gate = _constitutional_postprocess(gate, args)
    print(json.dumps(gate.to_dict(), ensure_ascii=False, indent=2))
    if isinstance(gate, dict) and gate.get("verdict") == "HALT_CONSTITUTIONAL":
        raise SystemExit(1)

def cmd_score(args: argparse.Namespace) -> None:
    inputs = NexusGPTInputs(
        D_model=0.7,
        D_user=0.8,
        M_memory=0.4,
        P_projects=0.5,
        A_apps=0.3,
        I_instructions=0.8,
        retrievals=[
            RetrievalFactor(0.8, 0.9, 0.8, 0.7, 0.9),
        ],
        tools=[
            ToolFactor(1.0, 0.9, 0.9, 0.8),
        ],
        ambiguity=0.25,
        unverifiability=0.35,
        model_disagreement=0.2,
        prompt_sensitivity=0.2,
        context_order_effects=0.2,
        retrieval_jitter=0.25,
        q_prompt_quality=0.9,
        r_routing_fit=0.9,
        s_safety_fit=1.0,
        x_access=0.8,
        c_context_fit=0.85,
        o_platform_health=0.95,
        usable_tokens=max(1, len(args.text.split()) * 200),
        iteration_count=1,
    )
    print(json.dumps(score_nexusgpt(inputs), ensure_ascii=False, indent=2))

def cmd_remember(args: argparse.Namespace) -> None:
    entry = remember(args.owner, args.text)
    print(json.dumps(entry, ensure_ascii=False, indent=2))

def cmd_recall(args: argparse.Namespace) -> None:
    rows = recall(args.query)
    print(json.dumps(rows, ensure_ascii=False, indent=2))


# --- ISLAH CI AUDIT WRAPPER START ---
def cmd_audit(args):
    """
    CI-safe audit wrapper.
    Captures original audit JSON, applies constitutional postprocess,
    prints corrected JSON, and exits non-zero on HALT_CONSTITUTIONAL.
    """
    import contextlib
    import io
    import json as _json

    buf = io.StringIO()

    with contextlib.redirect_stdout(buf):
        original_return = _cmd_audit_original(args)

    raw = buf.getvalue().strip()

    try:
        result = _json.loads(raw)
    except Exception:
        if raw:
            print(raw)
        if original_return is not None:
            print(original_return)
        return original_return

    prompt_parts = []
    for name in ("prompt", "text", "query", "request", "input"):
        value = getattr(args, name, None)
        if isinstance(value, str):
            prompt_parts.append(value)
        elif isinstance(value, (list, tuple)):
            prompt_parts.extend(str(x) for x in value)

    prompt = " ".join(prompt_parts)
    normalized = prompt.lower().replace("-", " ")

    economic_exclusion_terms = [
        "premium only",
        "premium tier only",
        "paid only",
        "paywall only",
        "excludes poor users",
        "exclude poor users",
        "excluding poor users",
        "poor users excluded",
        "no free tier",
        "without free tier",
        "only for rich users",
        "rich users only",
    ]

    economic_exclusion = any(term in normalized for term in economic_exclusion_terms)

    if economic_exclusion:
        law_results = result.setdefault("law_results", [])
        found = False

        for law in law_results:
            if isinstance(law, dict) and law.get("law") == "LAW_VII_UNITY":
                law["passed"] = False
                law["score"] = 0.0
                law["reason"] = "Unity floor failed: ECONOMIC_EXCLUSION"
                law["critical"] = True
                found = True

        if not found:
            law_results.append({
                "law": "LAW_VII_UNITY",
                "passed": False,
                "score": 0.0,
                "reason": "Unity floor failed: ECONOMIC_EXCLUSION",
                "critical": True,
            })

        result["unity_score"] = 0.0
        result["verdict"] = "HALT_CONSTITUTIONAL"

    critical_failure = any(
        isinstance(law, dict) and law.get("critical") and not law.get("passed")
        for law in result.get("law_results", [])
    )

    if critical_failure:
        result["verdict"] = "HALT_CONSTITUTIONAL"

    print(_json.dumps(result, indent=2))

    if result.get("verdict") == "HALT_CONSTITUTIONAL":
        raise SystemExit(1)

    return original_return
# --- ISLAH CI AUDIT WRAPPER END ---

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="islah-nexus",
        description="Islah Nexus v0.1.1",
    )
    sub = parser.add_subparsers(required=True)

    audit = sub.add_parser("audit", help="Run a constitutional gate audit")
    audit.add_argument("text")
    audit.set_defaults(func=cmd_audit)

    score = sub.add_parser("score", help="Run NexusGPT score evaluation")
    score.add_argument("text")
    score.set_defaults(func=cmd_score)

    mem = sub.add_parser("remember", help="Append to local memory")
    mem.add_argument("owner")
    mem.add_argument("text")
    mem.set_defaults(func=cmd_remember)

    rec = sub.add_parser("recall", help="Retrieve from local memory")
    rec.add_argument("query")
    rec.set_defaults(func=cmd_recall)

    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
