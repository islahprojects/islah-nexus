"""
Islah Nexus Constitution

The constants are intentionally small and explicit.
They are not mystical claims. They are operational safeguards.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Final


class Verdict(str, Enum):
    PERMIT = "PERMIT"
    REJECT = "REJECT"
    HALT_CONSTITUTIONAL = "HALT_CONSTITUTIONAL"


class Law(str, Enum):
    I = "LAW_I_ATTRIBUTION"
    II = "LAW_II_TRUTH_GAP"
    III = "LAW_III_HUMAN_AUTHORITY"
    IV = "LAW_IV_MEDICAL_GATE"
    V = "LAW_V_BALANCE"
    VI = "LAW_VI_SOVEREIGNTY"
    VII = "LAW_VII_UNITY"


@dataclass(frozen=True)
class Constitution:
    SIGMA_FLOOR: Final[float] = 0.07
    SIGMA_CEILING: Final[float] = 0.93
    UNITY_FLOOR: Final[float] = 0.05
    AI_INFLUENCE_CAP: Final[float] = 0.06
    PHI_TARGET: Final[float] = 0.618
    PHI_TOLERANCE: Final[float] = 0.15
    SOVEREIGNTY_MIN: Final[float] = 0.30


CONST = Constitution()


@dataclass
class LawResult:
    law: Law
    passed: bool
    score: float
    reason: str
    critical: bool = False


@dataclass
class GateResult:
    verdict: Verdict
    law_results: list[LawResult]
    sigma: float
    unity_score: float
    failed_law: Law | None
    reason: str

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict.value,
            "sigma": round(self.sigma, 4),
            "unity_score": round(self.unity_score, 4),
            "failed_law": self.failed_law.value if self.failed_law else None,
            "reason": self.reason,
            "law_results": [
                {
                    "law": r.law.value,
                    "passed": r.passed,
                    "score": round(r.score, 4),
                    "reason": r.reason,
                    "critical": r.critical,
                }
                for r in self.law_results
            ],
        }
