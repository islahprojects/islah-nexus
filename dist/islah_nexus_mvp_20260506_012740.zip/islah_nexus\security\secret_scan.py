﻿import re
from dataclasses import dataclass
from pathlib import Path


SECRET_PATTERNS = {
    "notion_token": re.compile(r"\bntn_[A-Za-z0-9_-]{20,}\b"),
    "bearer_token": re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{20,}\b", re.IGNORECASE),
    "generic_api_key": re.compile(r"\b(api[_-]?key|secret|token)\s*[:=]\s*[\"'][^\"']{12,}[\"']", re.IGNORECASE),
    "aws_access_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
}


DEFAULT_SKIP_DIRS = {
    ".git",
    "__pycache__",
    "dist",
    "checkpoints",
    "archive",
    ".venv",
    "venv",
}


@dataclass(frozen=True)
class SecretFinding:
    path: str
    line_number: int
    kind: str
    preview: str


def redact_secret(text: str) -> str:
    if len(text) <= 8:
        return "[REDACTED]"
    return text[:4] + "[REDACTED]" + text[-4:]


def scan_text(text: str, path: str = "<memory>"):
    findings = []

    for line_number, line in enumerate(text.splitlines(), start=1):
        for kind, pattern in SECRET_PATTERNS.items():
            for match in pattern.finditer(line):
                findings.append(
                    SecretFinding(
                        path=path,
                        line_number=line_number,
                        kind=kind,
                        preview=redact_secret(match.group(0)),
                    )
                )

    return findings


def should_skip(path: Path) -> bool:
    return any(part in DEFAULT_SKIP_DIRS for part in path.parts)


def scan_file(path: Path):
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        return []
    except OSError:
        return []

    return scan_text(text, str(path))


def scan_tree(root: Path):
    root = Path(root)
    findings = []

    for path in root.rglob("*"):
        if should_skip(path):
            continue
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".py", ".ps1", ".json", ".md", ".txt", ".env", ".example"}:
            continue

        findings.extend(scan_file(path))

    return findings


if __name__ == "__main__":
    findings = scan_tree(Path("."))

    if findings:
        print("SECRET_SCAN_FINDINGS")
        for finding in findings:
            print(f"{finding.path}:{finding.line_number} {finding.kind} {finding.preview}")
        raise SystemExit(1)

    print("SECRET_SCAN_PASS")
